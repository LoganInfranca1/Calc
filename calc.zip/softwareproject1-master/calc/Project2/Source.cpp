#include <iostream>

using namespace std;

int main() {

	system("start i.mp3");



}