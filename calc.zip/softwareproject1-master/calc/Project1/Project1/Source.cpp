#include <iostream>

using namespace std;

int main() {

	system("start download.png");



}